# Tubes-PBO
Aplikasi ini bernama JeghemaBetik sebagai sistem informasi pelaporan Barang Hilang lingkup ITERA<br>
Dibangun dengan spesifikasi umum, yaitu memuat konsep OOP, GUI, dan terkoneksi database.

GUI yang digunakan adalah Swing (dalam rencana)<br>
Untuk database menggunakan DBMS MySQL.

Beberapa fitur utamanya adalah<br>
1. Mencari dan melihat informasi barang hilang yang terlaporkan<br>
2. Daftar (pengumuman) barang hilang di linimasa atau landing page<br>
3. Form untuk pembuatan pengumuman penemuan barang hilang<br>
4. Form Login<br>
5. 
<br>

Setiap pengguna (_civitas academica_ ITERA) akan didaftarkan oleh administrator.
